create view ins_riviste (issn, nome, argomento, datapubblicazione, responsabile, prezzo, doi_articoli_pubblicati) as
SELECT riviste.issn,
       riviste.nome,
       riviste.argomento,
       riviste.datapubblicazione,
       riviste.responsabile,
       riviste.prezzo,
       jolly.text AS doi_articoli_pubblicati
FROM b.riviste,
     b.jolly;

alter table ins_riviste
    owner to postgres;

