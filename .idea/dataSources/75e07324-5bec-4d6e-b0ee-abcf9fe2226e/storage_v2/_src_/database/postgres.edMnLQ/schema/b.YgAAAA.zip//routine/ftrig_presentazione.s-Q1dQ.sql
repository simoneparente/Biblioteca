create function ftrig_presentazione() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
    IF NOT EXISTS(SELECT * FROM b.libro WHERE isbn = NEW.ISBN) THEN --Controllo se il libro esiste
        RAISE NOTICE 'Il libro non esiste!! Presentazione non inserita';
    ELSEIF EXISTS(SELECT *
                  FROM (b.evento as e NATURAL JOIN b.presentazione as p) --Controllo se esiste già una presentazione per quel libro
                           JOIN b.libro as l ON p.libro = l.ID_Libro
                  WHERE ISBN = NEW.ISBN) THEN
        RAISE NOTICE 'Esista già una presentazione per questo libro!! Presentazione non inserita';
    ELSE  --Inserisco la presentazione
        INSERT INTO b.evento (indirizzo, strutturaospitante, datainizio, datafine, responsabile) --Inserisco l'evento
        VALUES (NEW.Indirizzo, NEW.StrutturaOspitante, NEW.DataInizio, NEW.DataFine, NEW.Responsabile);
        INSERT INTO b.presentazione (evento, libro)  --Inserisco la presentazione
        SELECT e.ID_evento, l.ID_libro   --Trasformo l'ISBN in un ID e recupero l'ID dell'evento
        FROM b.evento e,
             b.libro l
        WHERE l.ISBN = NEW.ISBN
          AND e.indirizzo = NEW.Indirizzo
          AND e.strutturaospitante = NEW.StrutturaOspitante
          AND e.datainizio = NEW.DataInizio
          AND e.datafine = NEW.DataFine
          AND e.responsabile = NEW.Responsabile;
    END IF;
    RETURN NEW;
END
$$;

alter function ftrig_presentazione() owner to postgres;

