create function tfun_eventoconferenza() returns trigger
    language plpgsql
as
$$
DECLARE
    articoli    text[]  := string_to_array(NEW.Doi_Articoli_Presentati, '@');
    narticoli   INTEGER := array_length(articoli, 1);
    newarticolo b.articolo.id_articolo%TYPE;
    newevento   b.evento.ID_Evento%TYPE;
    vcheck      INTEGER := 0;
BEGIN
    --Verifico che tutti gli articoli esistano
    FOR i IN 1..narticoli
        LOOP
            IF NOT EXISTS(SELECT * FROM b.articolo WHERE doi = articoli[i]) THEN
                vcheck = 1;
            end if;
        end loop;

    --Se non esistono tutti gli articoli non inserisco l'evento
    IF (vcheck != 0) THEN
        RAISE NOTICE 'EVENTO NON INSERITO, UNO O PIU'' ARTICOLI SONO INESISTENTI';
    ELSE  --Se tutti gli articoli esistono inserisco l'evento
        INSERT INTO evento (indirizzo, strutturaospitante, datainizio, datafine, responsabile) --Inserisco l'evento
        VALUES (NEW.indirizzo, NEW.strutturaospitante, NEW.datainizio, NEW.datafine, NEW.responsabile);

        --Recupero l'id dell'evento appena inserito
        newevento = (SELECT id_evento
                     FROM b.evento
                     WHERE indirizzo = NEW.indirizzo
                       AND strutturaospitante = NEW.strutturaospitante
                       AND datainizio = NEW.datainizio
                       AND datafine = NEW.datafine
                       AND responsabile = NEW.responsabile);

        --Inserisco le conferenze per ogni articolo
        FOR i IN 1..narticoli
            LOOP
                newarticolo = (SELECT id_articolo FROM b.articolo WHERE doi = articoli[i]); --Recupero l'id dell'articolo
                INSERT INTO conferenza (articolo, evento) VALUES (newarticolo, newevento);
            end loop;
    END IF;
end
$$;

alter function tfun_eventoconferenza() owner to postgres;

