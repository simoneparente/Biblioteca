create view view_articoli_conferenza
            (titolo, doi, datapubblicazione, disciplina, editore, lingua, formato, titolo_conferenza) as
SELECT a.titolo,
       a.doi,
       a.datapubblicazione,
       a.disciplina,
       a.editore,
       a.lingua,
       a.formato,
       e.nome AS titolo_conferenza
FROM b.articoli a
         CROSS JOIN b.conferenza c
         JOIN b.evento e ON c.evento = e.id_evento;

alter table view_articoli_conferenza
    owner to postgres;

