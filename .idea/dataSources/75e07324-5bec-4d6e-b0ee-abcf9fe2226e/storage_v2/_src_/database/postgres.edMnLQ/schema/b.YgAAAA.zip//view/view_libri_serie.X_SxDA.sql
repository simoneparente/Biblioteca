create view view_libri_serie (titolo, isbn, datapubblicazione, editore, genere, lingua, formato, prezzo, nome_serie) as
SELECT l.titolo,
       l.isbn,
       l.datapubblicazione,
       l.editore,
       l.genere,
       l.lingua,
       l.formato,
       l.prezzo,
       s.nome AS nome_serie
FROM b.libri l
         CROSS JOIN b.libriinserie ls
         JOIN b.serie s ON ls.id_serie = s.id_serie;

alter table view_libri_serie
    owner to postgres;

