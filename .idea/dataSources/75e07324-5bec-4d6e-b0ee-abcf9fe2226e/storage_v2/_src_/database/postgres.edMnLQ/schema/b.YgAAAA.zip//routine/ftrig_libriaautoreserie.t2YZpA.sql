create function ftrig_libriaautoreserie() returns trigger
    language plpgsql
as
$$
DECLARE
    autori         text[]  := string_to_array(NEW.Autorinome_cognome, ' ');
    nautori        INTEGER := array_length(autori, 1);
    autore_nome    b.autore.nome%TYPE;
    autore_cognome b.autore.cognome%TYPE;
    newLibri       b.libri.ID_Libri%TYPE;
    newSerie       b.serie.ID_Serie%TYPE;
BEGIN
    --Verifico che il libri non sia già presente
    IF EXISTS(SELECT * FROM b.libri WHERE titolo = NEW.titolo AND datapubblicazione = NEW.datapubblicazione) THEN
        RAISE NOTICE 'Libri già presente';
    ELSE
        --Insert Libri
        INSERT INTO b.libri(titolo, ISBN, datapubblicazione, Editore, Genere, Lingua, Formato, Prezzo)
        VALUES (NEW.titolo, NEW.ISBN, NEW.datapubblicazione, NEW.editore, NEW.datapubblicazione, NEW.lingua,
                New.Formato, NEW.prezzo);
        --Insert Autori
        FOR i IN 1..nautori
            LOOP
                autore_nome := split_part(autori[i], '_', 1);
                autore_cognome := split_part(autori[i], '_', 2);

                --Verifico che l'autore non sia già presente
                IF EXISTS(SELECT * FROM b.autore WHERE nome = autore_nome AND cognome = autore_cognome) THEN
                    RAISE NOTICE 'Autore già presente {%}', autori[i];
                ELSE --Inserisco l'autore
                    INSERT INTO b.autore (nome, cognome) VALUES (autore_nome, autore_cognome);
                END IF;

                --Aggiorno la tabella autorelibri
                INSERT INTO b.autorelibri(id_autore, id_libri)
                SELECT a.id_autore, l.id_libri -- Trasformo l'ISNN in un ID e recupero l'ID dell'autore
                FROM b.autore as a,
                     b.libri as l
                WHERE a.nome = autore_nome
                  AND a.cognome = autore_cognome
                  AND l.titolo = NEW.titolo
                  AND l.datapubblicazione = NEW.datapubblicazione;
            END LOOP;

        --Insert Serie
        newLibri = (SELECT ID_Libri FROM b.libri WHERE ISBN = NEW.ISBN); -- Trasformo l'ISNN in un ID
        IF NEW.nome_serie_di_appartenenza IS NOT NULL AND
           NEW.issn_serie_di_appartenenza IS NOT NULL THEN -- Controllo se il libri fa parte di una serie
            RAISE NOTICE 'Fa parte di una Serie';

            --Verifico che la serie non sia già presente
            IF EXISTS(SELECT * FROM b.serie WHERE ISSN = NEW.ISSN_Serie_Di_Appartenenza) THEN
                newSerie = (SELECT id_serie FROM b.serie WHERE issn = New.ISSN_Serie_Di_Appartenenza);
                RAISE NOTICE 'Serie già presente';
                --Aggiorno il libri successivo
                UPDATE b.libriinserie
                SET librisuccessivo = newLibri
                WHERE id_serie = newSerie
                  AND librisuccessivo IS NULL;
                RAISE NOTICE 'LIBRi SUCCESSIVO INSERITO';

                --Aggiorno la tabella libriinserie
                INSERT INTO b.libriinserie (id_serie, libri) VALUES (newSerie, newLibri);
                RAISE NOTICE 'NUOVO LIBRi INSERITO';

            ELSE --NON ci sono altri libri, il libri è il primo della serie
                RAISE NOTICE 'Serie non presente';

                --Inserisco una nuova serie
                INSERT INTO b.serie (issn, nome)
                VALUES (NEW.ISSN_Serie_Di_Appartenenza, NEW.Nome_Serie_Di_Appartenenza);
                newSerie = (SELECT id_serie FROM b.serie WHERE issn = New.ISSN_Serie_Di_Appartenenza);
                RAISE NOTICE 'newserie{%}', newSerie;
                --Inserisco in libriinserie
                INSERT INTO b.libriinserie (id_serie, libri) VALUES (newSerie, newLibri);
                RAISE NOTICE 'NUOVO LIBRi INSERITO';
            end if;
        end if;
    END IF;
    RETURN NEW;
end;

$$;

alter function ftrig_libriaautoreserie() owner to postgres;

