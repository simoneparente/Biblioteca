create view ins_articolo_autore (doi, titolo, autorinome_cognome, datapubblicazione, editore, lingua, formato) as
SELECT articolo.doi,
       articolo.titolo,
       jolly.text AS autorinome_cognome,
       articolo.datapubblicazione,
       articolo.editore,
       articolo.lingua,
       articolo.formato
FROM b.articolo,
     b.jolly;

alter table ins_articolo_autore
    owner to postgres;

