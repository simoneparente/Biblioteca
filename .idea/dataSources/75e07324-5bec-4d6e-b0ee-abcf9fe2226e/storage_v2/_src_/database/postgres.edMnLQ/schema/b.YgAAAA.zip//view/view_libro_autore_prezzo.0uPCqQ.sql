create view view_libro_autore_prezzo (titolo, isbn, datapubblicazione, editore, genere, lingua, formato, prezzo) as
SELECT l.titolo,
       l.isbn,
       l.datapubblicazione,
       l.editore,
       l.genere,
       l.lingua,
       l.formato,
       l.prezzo
FROM b.libro l
         JOIN b.autorelibro al USING (id_libro)
         JOIN b.autore a ON al.id_autore = a.id_autore;

alter table view_libro_autore_prezzo
    owner to postgres;

