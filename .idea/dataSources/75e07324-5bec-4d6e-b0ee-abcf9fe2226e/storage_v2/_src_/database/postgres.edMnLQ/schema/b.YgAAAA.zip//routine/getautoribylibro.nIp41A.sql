create function getautoribylibro(inputidlibro integer) returns text
    language plpgsql
as
$$
DECLARE
    returnAutori     TEXT;
    cursore CURSOR FOR (SELECT nome, cognome
                        FROM (b.autore a NATURAL JOIN b.autorelibri al)
                                 JOIN b.libri l ON l.id_libri = al.id_libri
                        WHERE l.id_libri = inputIdLibro);
    dimensioneAutori INTEGER= (SELECT COUNT(*)
                               FROM (b.autore a NATURAL JOIN b.autorelibri al)
                                        JOIN b.libri l ON l.id_libri = al.id_libri
                               WHERE l.id_libri = inputIdLibro);
    autoreNome       b.autore.nome%TYPE;
    autoreCognome    b.autore.cognome%TYPE;
    controllo        bool= false; --se è a false non sono stati inseriti ancora autori in returnAutori
BEGIN
    OPEN cursore;
    FOR b IN 1..dimensioneAutori
        LOOP
            FETCH cursore INTO autoreNome, autoreCognome;
            if controllo IS false THEN
                returnAutori = autoreNome || ' ' || autoreCognome;
                controllo = true;
            else
                returnAutori=returnAutori || ', ' || autoreNome || ' ' || autoreCognome;
            end if;
        END LOOP;
    CLOSE cursore;
    return returnAutori;
END;
$$;

alter function getautoribylibro(integer) owner to postgres;

