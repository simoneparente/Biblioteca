create function ftrig_stocklibro() returns trigger
    language plpgsql
as
$$
DECLARE
    v_idlibro b.libro.id_libro%TYPE=(SELECT id_libro
                                     FROM b.libro
                                     WHERE isbn = NEW.isbn);
BEGIN
    IF NOT EXISTS(SELECT * FROM b.negozio WHERE id_negozio = NEW.id_negozio) OR --controllo che non esistano sia il negozio
       NOT EXISTS(SELECT * FROM b.libro WHERE id_libro = v_idlibro) THEN --sia il libro
        RAISE NOTICE 'ID Negozio o ISBN errati, dati non inseriti';
    ELSE
        --controllo se esista già una tupla composta da id_negozio e id_libro
        IF EXISTS(SELECT * FROM b.stock WHERE stock.negozio = NEW.id_negozio AND stock.libro = v_idlibro) THEN
            UPDATE b.stock
            SET quantita=quantita + NEW.quantita
            WHERE negozio = NEW.id_negozio AND stock.libro = v_idlibro;
        ELSE --se non esiste la creo
            INSERT INTO b.stock values (NEW.id_negozio, v_idlibro, NEW.quantita);
        end if;
    END IF;
    RETURN NEW;
END
$$;

alter function ftrig_stocklibro() owner to postgres;

