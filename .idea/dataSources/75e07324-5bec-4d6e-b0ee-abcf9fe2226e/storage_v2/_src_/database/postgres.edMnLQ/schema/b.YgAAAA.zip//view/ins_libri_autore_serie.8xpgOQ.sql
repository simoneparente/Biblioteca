create view ins_libri_autore_serie
            (titolo, isbn, autorinome_cognome, datapubblicazione, editore, genere, lingua, formato, prezzo,
             nome_serie_di_appartenenza, issn_serie_di_appartenenza)
as
SELECT l.titolo,
       l.isbn,
       j.text AS autorinome_cognome,
       l.datapubblicazione,
       l.editore,
       l.genere,
       l.lingua,
       l.formato,
       l.prezzo,
       s.nome AS nome_serie_di_appartenenza,
       s.issn AS issn_serie_di_appartenenza
FROM b.libri l,
     b.serie s,
     b.jolly j;

alter table ins_libri_autore_serie
    owner to postgres;

