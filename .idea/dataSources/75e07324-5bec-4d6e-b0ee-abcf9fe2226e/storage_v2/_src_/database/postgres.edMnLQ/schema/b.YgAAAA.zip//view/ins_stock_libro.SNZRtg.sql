create view ins_stock_libro(id_negozio, isbn, quantita) as
SELECT stock.negozio AS id_negozio,
       libro.isbn,
       stock.quantita
FROM b.libro,
     b.stock;

alter table ins_stock_libro
    owner to postgres;

