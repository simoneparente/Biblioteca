create view ins_conferenza
            (nome, indirizzo, strutturaospitante, datainizio, datafine, responsabile, doi_articoli_presentati) as
SELECT e.nome,
       e.indirizzo,
       e.strutturaospitante,
       e.datainizio,
       e.datafine,
       e.responsabile,
       jolly.text AS doi_articoli_presentati
FROM b.jolly,
     b.evento e;

alter table ins_conferenza
    owner to postgres;

