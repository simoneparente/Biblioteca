create function ftrig_conferenza() returns trigger
    language plpgsql
as
$$
DECLARE
    articoli    text[]  := string_to_array(NEW.Doi_Articoli_Presentati, ' ');
    narticoli   INTEGER := array_length(articoli, 1);
    newArticoli b.Articoli.id_Articoli%TYPE;
    newevento   b.evento.ID_Evento%TYPE;
    vcheck      INTEGER := 0;
BEGIN
    FOR i IN 1..narticoli
        LOOP
            newArticoli = (SELECT id_Articoli FROM b.Articoli WHERE doi = articoli[i]);
            --Controllo se l'Articoli esiste
            IF NOT EXISTS(SELECT * FROM b.Articoli WHERE doi = articoli[i]) THEN
                vcheck = 1;
                RAISE NOTICE 'Articoli {%} non presente', articoli[i];
            --Controllo se l'Articoli è già presente in una riviste
            ELSEIF EXISTS(SELECT * FROM b.Articoliinriviste WHERE id_Articoli = newArticoli) THEN
                vcheck = 2;
                RAISE NOTICE 'Articoli {%} già presente in una riviste', articoli[i];
            END IF;
        end loop;

    IF (vcheck = 1) THEN
        RAISE NOTICE 'EVENTO NON INSERITO, UNO O PIU'' ARTICOLI SONO INESISTENTI';
    ELSEIF (vcheck = 2) THEN
        RAISE NOTICE 'EVENTO NON INSERITO, UNO O PIU'' ARTICOLI SONO GIA'' PRESENTI IN UNA RIVISTe';
    ELSE --Se tutti gli articoli esistono inserisco l'evento
        INSERT INTO b.evento (nome, indirizzo, strutturaospitante, datainizio, datafine, responsabile) --Inserisco l'evento
        VALUES (NEW.nome, NEW.indirizzo, NEW.strutturaospitante, NEW.datainizio, NEW.datafine, NEW.responsabile);

        --Recupero l'id dell'evento appena inserito
        newevento = (SELECT id_evento
                     FROM b.evento
                     WHERE nome = NEW.nome
                       AND indirizzo = NEW.indirizzo
                       AND strutturaospitante = NEW.strutturaospitante
                       AND datainizio = NEW.datainizio
                       AND datafine = NEW.datafine
                       AND responsabile = NEW.responsabile);

        --Inserisco le conferenze per ogni Articoli
        FOR i IN 1..narticoli
            LOOP
                newArticoli =
                        (SELECT id_Articoli FROM b.Articoli WHERE doi = articoli[i]); --Recupero l'id dell'Articoli
                INSERT INTO b.conferenza (Articoli, evento) VALUES (newArticoli, newevento);
            end loop;
    END IF;
    RETURN NEW;
end
$$;

alter function ftrig_conferenza() owner to postgres;

