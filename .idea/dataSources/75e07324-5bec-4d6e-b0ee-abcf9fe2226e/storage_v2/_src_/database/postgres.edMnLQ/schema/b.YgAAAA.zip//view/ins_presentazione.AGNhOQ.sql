create view ins_presentazione (isbn, indirizzo, strutturaospitante, datainizio, datafine, responsabile) as
SELECT l.isbn,
       e.indirizzo,
       e.strutturaospitante,
       e.datainizio,
       e.datafine,
       e.responsabile
FROM b.evento e,
     b.libro l;

alter table ins_presentazione
    owner to postgres;

