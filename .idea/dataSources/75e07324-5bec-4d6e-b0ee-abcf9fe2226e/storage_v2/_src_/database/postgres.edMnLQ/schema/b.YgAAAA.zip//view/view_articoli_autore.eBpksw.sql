create view view_articoli_autore
            (titolo, doi, datapubblicazione, disciplina, editore, lingua, formato, nome, cognome) as
SELECT a.titolo,
       a.doi,
       a.datapubblicazione,
       a.disciplina,
       a.editore,
       a.lingua,
       a.formato,
       au.nome,
       au.cognome
FROM b.articoli a
         JOIN b.autorearticoli aa USING (id_articoli)
         JOIN b.autore au ON aa.id_autore = au.id_autore;

alter table view_articoli_autore
    owner to postgres;

