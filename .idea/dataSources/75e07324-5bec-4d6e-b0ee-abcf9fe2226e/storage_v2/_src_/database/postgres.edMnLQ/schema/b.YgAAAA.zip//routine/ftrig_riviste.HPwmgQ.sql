create function ftrig_riviste() returns trigger
    language plpgsql
as
$$
    DECLARE
    articoli    text[]  := string_to_array(NEW.Doi_Articoli_Pubblicati, '@');
    narticoli   INTEGER := array_length(articoli, 1);
    newArticoli b.Articoli.id_Articoli%TYPE;
    newriviste  b.riviste.ID_Riviste%TYPE;
    vcheck      INTEGER:=0;
    BEGIN
        FOR i IN 1..narticoli LOOP
            newArticoli = (SELECT id_Articoli FROM b.Articoli WHERE doi = articoli[i]);
            --Controllo se l'Articoli esiste
            IF NOT EXISTS(SELECT * FROM b.Articoli WHERE doi = articoli[i]) THEN
                RAISE NOTICE 'Articoli {%} non presente', articoli[i];
                vcheck := 1;
            --Controllo se l'Articoli è già presente in una conferenza
            ELSEIF EXISTS(SELECT * FROM b.conferenza WHERE Articoli = newArticoli) THEN
                RAISE NOTICE 'Articoli {%} già presente in una conferenza', articoli[i];
                vcheck := 2;
            END IF;
        END LOOP;

        IF (vcheck = 1) THEN
            RAISE NOTICE 'EVENTO NON INSERITO, UNO O PIU'' ARTICOLI SONO INESISTENTI ';
        ELSIF (vcheck = 2) THEN
            RAISE NOTICE 'EVENTO NON INSERITO, UNO O PIU'' ARTICOLI SONO GIA'' PRESENTI IN UNA CONFERENZA ';
        ELSE
            --Inserisco la riviste
            INSERT INTO b.riviste (nome, issn, argomento, datapubblicazione, responsabile, prezzo)
            VALUES (NEW.nome, NEW.issn, NEW.argomento, NEW.datapubblicazione, NEW.responsabile, NEW.prezzo);

            --Recupero l'id della riviste appena inserita
            SELECT id_riviste INTO newriviste FROM b.riviste WHERE nome = NEW.nome AND issn = NEW.issn;

            --Inserisco gli articoli nella riviste
            FOR i IN 1..narticoli LOOP
                SELECT id_Articoli INTO newArticoli FROM b.Articoli WHERE doi = articoli[i]; --recupero id Articoli
                INSERT INTO b.Articoliinriviste (id_Articoli, id_riviste)
                VALUES (newArticoli, newriviste);
            END LOOP;
        END IF;
        RETURN NEW;
    END;
$$;

alter function ftrig_riviste() owner to postgres;

