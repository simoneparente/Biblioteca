create view ins_stock_libri(id_negozio, isbn, quantita) as
SELECT stock.negozio AS id_negozio,
       libri.isbn,
       stock.quantita
FROM b.libri,
     b.stock;

alter table ins_stock_libri
    owner to postgres;

