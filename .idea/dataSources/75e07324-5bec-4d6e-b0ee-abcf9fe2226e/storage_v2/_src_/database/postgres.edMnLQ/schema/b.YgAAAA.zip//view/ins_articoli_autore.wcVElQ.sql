create view ins_articoli_autore
            (doi, titolo, autorinome_cognome, datapubblicazione, disciplina, editore, lingua, formato) as
SELECT articoli.doi,
       articoli.titolo,
       jolly.text AS autorinome_cognome,
       articoli.datapubblicazione,
       articoli.disciplina,
       articoli.editore,
       articoli.lingua,
       articoli.formato
FROM b.articoli,
     b.jolly;

alter table ins_articoli_autore
    owner to postgres;

