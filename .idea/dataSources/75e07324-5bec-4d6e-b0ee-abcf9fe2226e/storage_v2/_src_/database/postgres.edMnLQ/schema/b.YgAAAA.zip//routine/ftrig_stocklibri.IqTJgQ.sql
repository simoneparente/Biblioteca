create function ftrig_stocklibri() returns trigger
    language plpgsql
as
$$
DECLARE
    v_idlibri b.libri.id_libri%TYPE=(SELECT id_libri
                                     FROM b.libri
                                     WHERE isbn = NEW.isbn);
BEGIN
    IF NOT EXISTS(SELECT * FROM b.negozio WHERE id_negozio = NEW.id_negozio) OR --controllo che non esistano sia il negozio
       NOT EXISTS(SELECT * FROM b.libri WHERE id_libri = v_idlibri) THEN --sia il libri
        RAISE NOTICE 'ID Negozio o ISBN errati, dati non inseriti';
    ELSE
        --controllo se esista già una tupla composta da id_negozio e id_libri
        IF EXISTS(SELECT * FROM b.stock WHERE stock.negozio = NEW.id_negozio AND stock.libri = v_idlibri) THEN
            UPDATE b.stock
            SET quantita=quantita + NEW.quantita
            WHERE negozio = NEW.id_negozio
              AND stock.libri = v_idlibri;
        ELSE --se non esiste la creo
            INSERT INTO b.stock values (NEW.id_negozio, v_idlibri, NEW.quantita);
        end if;
    END IF;
    RETURN NEW;
END
$$;

alter function ftrig_stocklibri() owner to postgres;

