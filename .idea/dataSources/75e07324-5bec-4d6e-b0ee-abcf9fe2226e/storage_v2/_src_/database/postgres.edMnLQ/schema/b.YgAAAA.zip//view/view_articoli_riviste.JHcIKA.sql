create view view_articoli_riviste
            (titolo, doi, datapubblicazione, disciplina, editore, lingua, formato, titolo_riviste) as
SELECT a.titolo,
       a.doi,
       a.datapubblicazione,
       a.disciplina,
       a.editore,
       a.lingua,
       a.formato,
       r.nome AS titolo_riviste
FROM b.articoli a
         JOIN b.articoliinriviste ar USING (id_articoli)
         JOIN b.riviste r ON ar.id_riviste = r.id_riviste;

alter table view_articoli_riviste
    owner to postgres;

