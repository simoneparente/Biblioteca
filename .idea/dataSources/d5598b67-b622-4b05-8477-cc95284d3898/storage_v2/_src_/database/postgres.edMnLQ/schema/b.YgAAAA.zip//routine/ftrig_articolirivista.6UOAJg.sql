create function ftrig_articolirivista() returns trigger
    language plpgsql
as
$$
DECLARE
    idRivista  b.riviste.id_rivista%TYPE;
    idArticolo INTEGER;
BEGIN
    --Controllo che l'articolo non sia già presente nel DataBase
    IF EXISTS(SELECT * FROM b.articoli WHERE doi = NEW.doi) THEN
        RAISE NOTICE 'Articolo già presente, non verrà inserito';
    ELSE
        --Controllo che la rivista non sia già presente nel DataBase in tal caso la inserisco
        IF NOT EXISTS(SELECT * FROM b.riviste WHERE issn = NEW.issnRivista) THEN
            RAISE NOTICE 'Rivista non presente, verrà inserita';
            INSERT INTO b.riviste (nome, issn, argomento, datapubblicazione, responsabile, prezzo)
            VALUES (NEW.nomeRivista, NEW.issnRivista, NEW.argomentoRivista, NEW.datapubblicazione,
                    NEW.responsabileRivista, NEW.prezzoRivista);
            --Controllo che la rivista presente nel database abbia la stessa data di pubblicazione
        ELSEIF NOT EXISTS(SELECT datapubblicazione
                          FROM b.riviste
                          WHERE issn = NEW.issnRivista
                            AND datapubblicazione = NEW.datapubblicazione) THEN
            RAISE NOTICE 'Rivista già presente ma con data di pubblicazione diversa, l''articolo non verrà inserito';
            RETURN NEW;
        END IF;
        --Inserisco l'articolo
        INSERT INTO b.articoli (doi, titolo, datapubblicazione, disciplina, editore, lingua, formato)
        VALUES (NEW.doi, NEW.titolo, NEW.datapubblicazione, NEW.disciplina, NEW.editore, NEW.lingua, NEW.formato);

        --Recupero l'id dell'articolo appena inserito
        idArticolo = (SELECT id_articolo FROM b.articoli WHERE doi = NEW.doi);

        --Inserisco gli autori richiamando la procedura insAutori
        CALL b.insAutori(NEW.AutoriNome_Cognome, idArticolo, 0);

        --Inserisco l'articolo nella rivista
        idRivista = (SELECT id_rivista FROM b.riviste WHERE issn = NEW.issnRivista);
        INSERT INTO b.articoliInRiviste (id_articolo, id_rivista) VALUES (idArticolo, idRivista);
    END IF;
    RETURN NEW;
END;
$$;

alter function ftrig_articolirivista() owner to postgres;

