create function getdisponibilitaserie(inputserie integer) returns boolean
    language plpgsql
as
$$
DECLARE
    scorrilibri b.libri.id_libro%TYPE;
    cursoreLibri CURSOR FOR (SELECT id_libro
                             FROM b.libriinserie
                             WHERE id_serie = inputSerie);
BEGIN
    OPEN cursorelibri;
    LOOP
        FETCH cursoreLibri INTO scorrilibri;
        EXIT WHEN NOT FOUND;
        IF NOT b.getDisponibilitaLibro(scorrilibri) THEN
            CLOSE cursoreLibri;
            return false;
        END IF;
    END LOOP;
    CLOSE cursoreLibri;
    return true;
END;
$$;

alter function getdisponibilitaserie(integer) owner to postgres;

