create view ins_presentazione (isbn, nome, indirizzo, strutturaospitante, datainizio, datafine, responsabile) as
SELECT l.isbn,
       e.nome,
       e.indirizzo,
       e.strutturaospitante,
       e.datainizio,
       e.datafine,
       e.responsabile
FROM b.evento e,
     b.libri l;

alter table ins_presentazione
    owner to postgres;

