create procedure insautori(IN stringautori text, IN idrisorsa integer, IN tiporisorsa integer)
    language plpgsql
as
$$
DECLARE
    autori        text[]  = string_to_array(stringAutori, ',');
    numAutori     INTEGER = array_length(autori, 1);
    autoreNome    b.autore.nome%TYPE;
    autoreCognome b.autore.cognome%TYPE;
    idAutore      b.autore.id_autore%TYPE;
BEGIN
    FOR i IN 1..numAutori
        LOOP
            autoreNome = split_part(autori[i], '_', 1);
            autoreNome = ltrim(autoreNome, ' ');
            autoreCognome = split_part(autori[i], '_', 2);
            autoreCognome = ltrim(autoreCognome, ' ');
            RAISE NOTICE 'autoreNome: % autoreCognome: %', autoreNome, autoreCognome;
            IF NOT EXISTS(SELECT * FROM b.autore WHERE nome = autoreNome AND cognome = autoreCognome) THEN
                RAISE NOTICE 'Autore non presente, verrà inserito';
                INSERT INTO b.autore (nome, cognome) VALUES (autoreNome, autoreCognome);
            END IF;
            idAutore = (SELECT id_autore FROM b.autore WHERE nome = autoreNome AND cognome = autoreCognome);
            IF (tipoRisorsa = 1) THEN
                INSERT INTO b.autorelibro (id_autore, id_libro) VALUES (idAutore, idRisorsa);
            ELSEIF (tipoRisorsa = 0) THEN
                INSERT INTO b.autorearticolo (id_autore, id_articolo) VALUES (idAutore, idRisorsa);
            END IF;
        END LOOP;
END
$$;

alter procedure insautori(text, integer, integer) owner to postgres;

