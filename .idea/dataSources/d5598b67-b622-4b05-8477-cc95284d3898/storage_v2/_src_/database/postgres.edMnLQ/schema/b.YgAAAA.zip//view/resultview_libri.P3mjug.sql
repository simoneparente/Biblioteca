create view resultview_libri
            (titolo, isbn, autori, datapubblicazione, editore, genere, lingua, serie, formato, prezzo, disponibilità) as
SELECT DISTINCT l.titolo,
                l.isbn,
                b.getautoribylibro(l.id_libro) AS autori,
                l.datapubblicazione,
                l.editore,
                l.genere,
                l.lingua,
                s.nome                         AS serie,
                l.formato,
                l.prezzo,
                b.getdisponibilita(l.id_libro) AS "disponibilità"
FROM b.libri l
         FULL JOIN b.libriinserie lis ON l.id_libro = lis.id_libro
         FULL JOIN b.serie s ON lis.id_serie = s.id_serie;

alter table resultview_libri
    owner to postgres;

