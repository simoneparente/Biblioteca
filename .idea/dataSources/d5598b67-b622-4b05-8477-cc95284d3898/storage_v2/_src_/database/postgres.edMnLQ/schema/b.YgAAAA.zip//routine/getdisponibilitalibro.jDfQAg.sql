create function getdisponibilitalibro(inputlibro integer) returns boolean
    language plpgsql
as
$$
DECLARE
BEGIN
    IF EXISTS(SELECT * FROM b.stock s WHERE s.id_libro = inputLibro) THEN
        return true;
    ELSE
        return false;
    END IF;
END;
$$;

alter function getdisponibilitalibro(integer) owner to postgres;

