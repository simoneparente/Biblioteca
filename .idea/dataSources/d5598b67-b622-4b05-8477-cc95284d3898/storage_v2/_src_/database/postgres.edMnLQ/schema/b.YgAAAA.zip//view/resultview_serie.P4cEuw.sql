create view resultview_serie (nome, issn, editore, lingua, formato, datapubblicazione, disponibilità) as
SELECT DISTINCT ON (s.issn) s.nome,
                            s.issn,
                            l.editore,
                            l.lingua,
                            l.formato,
                            l.datapubblicazione,
                            b.getdisponibilitaserie(s.issn) AS "disponibilità"
FROM b.libri l
         JOIN b.libriinserie ls USING (id_libro)
         JOIN b.serie s ON ls.id_serie = s.id_serie;

alter table resultview_serie
    owner to postgres;

