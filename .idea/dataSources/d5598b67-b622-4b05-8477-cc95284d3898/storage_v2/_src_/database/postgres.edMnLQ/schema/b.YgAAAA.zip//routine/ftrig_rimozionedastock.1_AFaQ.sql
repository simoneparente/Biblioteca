create function ftrig_rimozionedastock() returns trigger
    language plpgsql
as
$$
BEGIN
    --Controllo se la quantità è 0 e in tal caso rimuovo il libro dallo stock
    if (NEW.quantita = 0) then
        DELETE FROM b.stock WHERE id_libro = OLD.id_libro;
    end if;
END;
$$;

alter function ftrig_rimozionedastock() owner to postgres;

