create function getdisponibilitaserie(inputserieissn character varying) returns boolean
    language plpgsql
as
$$
DECLARE
    scorrilibri b.libri.id_libro%TYPE;
    cursoreLibri CURSOR FOR (SELECT id_libro
                             FROM (b.libri l NATURAL JOIN b.libriinserie ls)
                                      JOIN b.serie s ON s.id_serie = ls.id_serie
                             WHERE ISSN = inputSerieISSN);
BEGIN
    OPEN cursorelibri;
    LOOP
        FETCH cursoreLibri INTO scorrilibri;
        EXIT WHEN NOT FOUND;
        if NOT b.getDisponibilita(scorrilibri) THEN
            CLOSE cursoreLibri;
            return false;
        end if;
    end loop;
    CLOSE cursoreLibri;
    return true;
end;
$$;

alter function getdisponibilitaserie(varchar) owner to postgres;

