create function getautoribyarticolo(inputidarticolo integer) returns text
    language plpgsql
as
$$
DECLARE
    autoreNome    b.autore.nome%TYPE;
    autoreCognome b.autore.cognome%TYPE;
    returnAutori  TEXT;
    controllo     bool= false; --se è a false non sono stati inseriti ancora autori in returnAutori
    cursore cursor for (SELECT nome, cognome
                        FROM (b.autore a NATURAL JOIN b.autorearticolo aa)
                                 JOIN b.articoli ar ON ar.id_articolo = aa.id_articolo
                        WHERE ar.id_articolo = inputIdArticolo);
BEGIN
    open cursore;
    LOOP
        FETCH cursore INTO autoreNome, autoreCognome;
        EXIT WHEN NOT FOUND;
        if controllo IS false THEN
            returnAutori = autoreNome || ' ' || autoreCognome;
            controllo = true;
        else
            returnAutori = returnAutori || ', ' || autoreNome || ' ' || autoreCognome;
        end if;
    END LOOP;
    CLOSE cursore;
    return returnAutori;
end;
$$;

alter function getautoribyarticolo(integer) owner to postgres;

