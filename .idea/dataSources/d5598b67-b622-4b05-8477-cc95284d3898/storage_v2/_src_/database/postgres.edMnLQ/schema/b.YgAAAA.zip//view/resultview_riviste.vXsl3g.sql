create view resultview_riviste(nome, issn, disciplina, editore, lingua, formato, datapubblicazione) as
SELECT DISTINCT r.nome,
                r.issn,
                a.disciplina,
                a.editore,
                a.lingua,
                a.formato,
                r.datapubblicazione
FROM b.articoli a
         JOIN b.articoliinriviste ar USING (id_articolo)
         JOIN b.riviste r ON ar.id_rivista = r.id_rivista;

alter table resultview_riviste
    owner to postgres;

