create view ins_stock(id_negozio, isbn, quantita) as
SELECT stock.id_negozio,
       libri.isbn,
       stock.quantita
FROM b.libri,
     b.stock;

alter table ins_stock
    owner to postgres;

