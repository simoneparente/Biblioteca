create function ftrig_rimozinearticoli() returns trigger
    language plpgsql
as
$$
DECLARE
    idAutoreArticolo b.autore.id_autore%TYPE;
    idAutoreArticoli CURSOR FOR SELECT id_autore
                                FROM b.autorearticolo
                                WHERE id_articolo = OLD.id_articolo;
    idRivista        b.riviste.id_rivista%TYPE = (SELECT id_rivista
                                                  FROM b.articoliinriviste
                                                  WHERE id_articolo = OLD.id_articolo);
    IdConferenza     b.evento.id_evento%TYPE   = (SELECT id_evento
                                                  FROM b.conferenza
                                                  WHERE id_articolo = OLD.id_articolo);
BEGIN
    --Rimuovo gli autori se non hanno scritto altri articoli o libri
    OPEN idAutoreArticoli;
    LOOP
        FETCH idAutoreArticoli INTO idAutoreArticolo;
        EXIT WHEN NOT FOUND;
        IF NOT EXISTS(SELECT id_autore
                      FROM b.autorearticolo
                      WHERE id_autore = idAutoreArticolo
                        AND id_articolo <> OLD.id_articolo) THEN
            IF NOT EXISTS(SELECT * FROM b.autorelibro WHERE id_autore = idAutoreArticolo) THEN
                DELETE FROM b.autore WHERE id_autore = idAutoreArticolo;
            END IF;
        END IF;
    END LOOP;

    --Rimuovo la Rivista se non ha altri articoli
    IF NOT EXISTS(SELECT *
                  FROM b.articoliinriviste
                  WHERE id_articolo <> old.id_articolo
                    AND id_rivista = idRivista) THEN
        DELETE FROM b.riviste WHERE id_rivista = idRivista;
    END IF;

    --Rimuovo Conferenza se non ha altri articoli
    IF NOT EXISTS(SELECT *
                  FROM b.conferenza
                  WHERE id_articolo <> old.id_articolo
                    AND id_evento = IdConferenza) THEN
        DELETE FROM b.evento WHERE id_evento = IdConferenza;
    END IF;

    CLOSE idAutoreArticoli;
    RETURN NEW;
END;
$$;

alter function ftrig_rimozinearticoli() owner to postgres;

