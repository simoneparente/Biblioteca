create view view_articoli_riviste
            (titolo, doi, datapubblicazione, disciplina, editore, lingua, formato, titolo_riviste) as
SELECT a.titolo,
       a.doi,
       a.datapubblicazione,
       a.disciplina,
       a.editore,
       a.lingua,
       a.formato,
       r.nome AS titolo_riviste
FROM b.articoli a
         JOIN b.articoliinriviste ar USING (id_articolo)
         JOIN b.riviste r ON ar.id_rivista = r.id_rivista;

alter table view_articoli_riviste
    owner to postgres;

