create view resultview_articoli (titolo, doi, autori, lingua, formato, editore, disciplina, datapubblicazione) as
SELECT DISTINCT a.titolo,
                a.doi,
                b.getautoribyarticolo(a.id_articolo) AS autori,
                a.lingua,
                a.formato,
                a.editore,
                a.disciplina,
                a.datapubblicazione
FROM b.articoli a
         JOIN b.autorearticolo USING (id_articolo);

alter table resultview_articoli
    owner to postgres;

