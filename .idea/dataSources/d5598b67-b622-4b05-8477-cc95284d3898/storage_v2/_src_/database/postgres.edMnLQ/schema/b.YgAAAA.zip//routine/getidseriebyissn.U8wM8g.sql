create function getidseriebyissn(issnin character varying) returns integer
    language plpgsql
as
$$
DECLARE
    id b.serie.id_serie%TYPE;
BEGIN
    RAISE NOTICE 'ISSN(%)', issnIn;
    id = (SELECT id_serie
          FROM b.serie se
          WHERE se.issn = issnIn);
    RAISE NOTICE 'ID{%}', id;
    RETURN id;
end;
$$;

alter function getidseriebyissn(varchar) owner to postgres;

