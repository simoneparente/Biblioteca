create view notifiche(nome, disponibile_in, issn, username) as
SELECT s.nome,
       b.getnegoziconserie(b.getidseriebyissn(s.issn)) AS disponibile_in,
       s.issn,
       u.username
FROM b.serie s
         JOIN b.richiesta r ON s.id_serie = r.id_serie
         JOIN b.utente u ON u.id_utente = r.id_utente
WHERE b.getdisponibilitaserie(r.id_serie) IS TRUE;

alter table notifiche
    owner to postgres;

