create view resultview_notifiche(nome, disponibile_in) as
SELECT notifiche.nome,
       notifiche.disponibile_in
FROM b.notifiche;

alter table resultview_notifiche
    owner to postgres;

