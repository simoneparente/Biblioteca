create function ftrig_libri() returns trigger
    language plpgsql
as
$$
DECLARE
    idLibro b.libri.ID_Libro%TYPE;
    idSerie b.serie.ID_Serie%TYPE;
BEGIN
    --Controllo che il libro non sia già presente nel DataBase
    IF EXISTS(SELECT * FROM b.libri WHERE isbn = NEW.isbn) THEN
        RAISE NOTICE 'Libro già presente';
    ELSE
        --Controllo che la serie di appartenenza del libro non sia già presente nel DataBase in tal caso la inserisco
        IF NOT EXISTS(SELECT * FROM b.serie WHERE issn = NEW.issn_serie_di_appartenenza) THEN
            RAISE NOTICE 'Serie non presente';
            IF NEW.nome_serie_di_appartenenza IS NOT NULL THEN
                INSERT INTO b.serie(nome, issn) values (NEW.nome_serie_di_appartenenza, NEW.issn_serie_di_appartenenza);
            END IF;
            --Controllo che il formato del libro sia compatibile con la serie già presente nel DataBase
        ELSEIF NOT EXISTS(SELECT *
                          FROM (b.serie s NATURAL JOIN b.libriinserie ls)
                                   JOIN b.libri l ON ls.id_libro = l.id_libro
                          WHERE l.formato = NEW.formato) THEN
            RAISE NOTICE 'Il formato del libro non è compatibile con la serie, libro non inserito';
            RETURN NEW;
        END IF;
        --Inserisco il libro
        INSERT INTO b.libri (titolo, isbn, datapubblicazione, editore, genere, lingua, formato, prezzo)
        VALUES (NEW.titolo, NEW.isbn, NEW.datapubblicazione, NEW.editore, NEW.genere, NEW.lingua, NEW.formato,
                NEW.prezzo);
        --Recupero l'id del libro appena inserito
        idLibro = (SELECT id_libro FROM b.libri WHERE isbn = NEW.isbn);

        --Inserisco gli autori richiamando la procedura insAutori
        CALL b.insAutori(NEW.autoriNome_cognome, idLibro, 1);

        --Inserisco il libro nella serie
        idSerie = (SELECT id_serie FROM b.serie WHERE issn = NEW.issn_serie_di_appartenenza);
        RAISE NOTICE 'idSerie: %', idSerie;
        IF idSerie IS NOT NULL THEN
            INSERT INTO b.libriinserie (id_libro, id_serie) VALUES (idLibro, idSerie);
        END IF;
    END IF;
    RETURN NEW;
END
$$;

alter function ftrig_libri() owner to postgres;

