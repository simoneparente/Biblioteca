create view ins_articoliconferenze
            (doi, titolo, autorinome_cognome, datapubblicazione, disciplina, editore, lingua, formato, nomeconferenza,
             indirizzoconferenza, strutturaospitanteconferenza, datainizioconferenza, datafineconferenza,
             responsabileconferenza)
as
SELECT a.doi,
       a.titolo,
       jolly.text           AS autorinome_cognome,
       a.datapubblicazione,
       a.disciplina,
       a.editore,
       a.lingua,
       a.formato,
       e.nome               AS nomeconferenza,
       e.indirizzo          AS indirizzoconferenza,
       e.strutturaospitante AS strutturaospitanteconferenza,
       e.datainizio         AS datainizioconferenza,
       e.datafine           AS datafineconferenza,
       e.responsabile       AS responsabileconferenza
FROM b.articoli a,
     b.jolly,
     b.evento e;

alter table ins_articoliconferenze
    owner to postgres;

