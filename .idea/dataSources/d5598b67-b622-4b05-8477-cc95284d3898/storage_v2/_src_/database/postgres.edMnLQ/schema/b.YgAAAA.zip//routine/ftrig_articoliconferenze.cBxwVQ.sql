create function ftrig_articoliconferenze() returns trigger
    language plpgsql
as
$$
DECLARE
    idArticolo   INTEGER;
    idConferenza b.evento.id_evento%TYPE;
BEGIN
    --Controllo che l'articolo non sia già presente nel DataBase
    IF EXISTS(SELECT * FROM b.articoli WHERE doi = NEW.doi) THEN
        RAISE NOTICE 'Articolo già presente, non verrà inserito';
        --Controllo se la data di pubblicazione dell'articolo è compresa tra la data di inizio e la data di fine della conferenza
    ELSEIF (NEW.datapubblicazione < NEW.datainizioConferenza OR NEW.datapubblicazione > NEW.datafineConferenza) THEN
        RAISE NOTICE 'La data di pubblicazione dell''articolo non è compresa tra la data di inizio e la data di fine della conferenza, l''articolo non verrà inserito';
    ELSE
        --Controllo che la conferenza non sia già presente nel DataBase in tal caso la inserisco
        IF NOT EXISTS(SELECT *
                      FROM b.evento
                      WHERE nome = NEW.nomeConferenza
                        AND indirizzo = NEW.indirizzoConferenza
                        AND datainizio = NEW.dataInizioConferenza) THEN
            RAISE NOTICE 'Conferenza non presente, verrà inserita';
            INSERT INTO b.evento (nome, indirizzo, strutturaospitante, datainizio, datafine, responsabile)
            VALUES (NEW.nomeConferenza, NEW.indirizzoConferenza, NEW.strutturaospitanteConferenza,
                    NEW.datainizioConferenza, NEW.datafineConferenza, NEW.responsabileConferenza);
        END IF;
        --Inserisco l'articolo
        INSERT INTO b.articoli (doi, titolo, datapubblicazione, disciplina, editore, lingua, formato)
        VALUES (NEW.doi, NEW.titolo, NEW.datapubblicazione, NEW.disciplina, NEW.editore, NEW.lingua, NEW.formato);

        --Recupero l'id dell'articolo appena inserito
        idArticolo = (SELECT id_articolo FROM b.articoli WHERE doi = NEW.doi);

        --Inserisco gli autori richiamando la procedura insAutori
        CALL b.insAutori(NEW.AutoriNome_Cognome, idArticolo, 0);

        --Inserisco l'articolo nella conferenza
        idConferenza = (SELECT id_evento
                        FROM b.evento
                        WHERE nome = NEW.nomeConferenza
                          AND indirizzo = NEW.indirizzoConferenza);
        INSERT INTO b.Conferenza (id_articolo, id_evento) VALUES (idArticolo, idConferenza);
    END IF;
    RETURN NEW;
END ;
$$;

alter function ftrig_articoliconferenze() owner to postgres;

