create view view_libri_serie
            (titolo, isbn, datapubblicazione, editore, genere, lingua, formato, prezzo, nome_serie, issn) as
SELECT DISTINCT l.titolo,
                l.isbn,
                l.datapubblicazione,
                l.editore,
                l.genere,
                l.lingua,
                l.formato,
                l.prezzo,
                s.nome AS nome_serie,
                s.issn
FROM b.libri l
         JOIN b.libriinserie ls USING (id_libro)
         JOIN b.serie s ON ls.id_serie = s.id_serie;

alter table view_libri_serie
    owner to postgres;

