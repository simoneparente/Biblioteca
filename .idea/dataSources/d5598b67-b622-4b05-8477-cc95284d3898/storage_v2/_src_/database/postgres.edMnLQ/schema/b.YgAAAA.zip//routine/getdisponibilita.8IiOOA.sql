create function getdisponibilita(inputlibro integer) returns boolean
    language plpgsql
as
$$
DECLARE
BEGIN
    IF EXISTS(SELECT * FROM b.stock s WHERE s.id_libro = inputLibro) THEN
        return true;
    else
        return false;
    end if;
END;
$$;

alter function getdisponibilita(integer) owner to postgres;

