create view view_libri_autore
            (titolo, isbn, datapubblicazione, editore, genere, lingua, formato, prezzo, nome, cognome) as
SELECT l.titolo,
       l.isbn,
       l.datapubblicazione,
       l.editore,
       l.genere,
       l.lingua,
       l.formato,
       l.prezzo,
       a.nome,
       a.cognome
FROM b.libri l
         JOIN b.autorelibro al USING (id_libro)
         JOIN b.autore a ON al.id_autore = a.id_autore;

alter table view_libri_autore
    owner to postgres;

