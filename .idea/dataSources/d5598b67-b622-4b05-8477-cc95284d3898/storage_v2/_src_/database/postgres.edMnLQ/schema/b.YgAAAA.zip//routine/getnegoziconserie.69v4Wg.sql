create function getnegoziconserie(id_seriein integer) returns character varying
    language plpgsql
as
$$
DECLARE
    nomi_negozi  VARCHAR := '';
    cursore CURSOR FOR (SELECT ne.nome
                        FROM (b.serie s JOIN b.libriinserie ls ON ls.id_serie = s.id_serie)
                                 JOIN (b.stock st JOIN b.negozio ne ON st.id_negozio = ne.id_negozio)
                                      ON st.id_libro = ls.id_libro
                        WHERE s.id_serie = id_SerieIn);
    n_negozi     INTEGER=(SELECT COUNT(*)
                          FROM (b.serie s JOIN b.libriinserie ls ON ls.id_serie = s.id_serie)
                                   JOIN b.stock st ON st.id_libro = ls.id_libro
                          WHERE s.id_serie = id_SerieIn);
    nome_negozio b.negozio.nome%TYPE;

BEGIN
    OPEN cursore;
    FOR i IN 1..n_negozi
        LOOP
            FETCH cursore INTO nome_negozio;
            if (i <> n_negozi) then
                nomi_negozi = nomi_negozi || nome_negozio || ', ';
            else
                nomi_negozi = nomi_negozi || nome_negozio;
            end if;
        end loop;
    CLOSE cursore;
    return nomi_negozi;
end;
$$;

alter function getnegoziconserie(integer) owner to postgres;

