create view ins_articolirivista
            (doi, titolo, autorinome_cognome, datapubblicazione, disciplina, editore, lingua, formato, nomerivista,
             issnrivista, argomentorivista, responsabilerivista, prezzorivista)
as
SELECT a.doi,
       a.titolo,
       jolly.text     AS autorinome_cognome,
       a.datapubblicazione,
       a.disciplina,
       a.editore,
       a.lingua,
       a.formato,
       r.nome         AS nomerivista,
       r.issn         AS issnrivista,
       r.argomento    AS argomentorivista,
       r.responsabile AS responsabilerivista,
       r.prezzo       AS prezzorivista
FROM b.articoli a,
     b.jolly,
     b.riviste r;

alter table ins_articolirivista
    owner to postgres;

